public class InsufficientFunds extends Exception {
  
  public InsufficientFunds(String message) {
      super(message);
  } // end InsufficientFunds

} // end class